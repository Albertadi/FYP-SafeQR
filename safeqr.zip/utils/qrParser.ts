export type QRContentType = "url" | "sms" | "tel" | "mailto" | "wifi" | "text"

export interface ParsedQRContent {
  contentType: QRContentType
  data: {
    originalContent: string
    [key: string]: any // Allow for other properties based on type
  }
}

/**
 * Parses the raw QR code content to determine its type and extract relevant data.
 * @param rawContent The raw string decoded from the QR code.
 * @returns An object containing the content type and parsed data.
 */
export function parseQrContent(rawContent: string): ParsedQRContent {
  const trimmedContent = rawContent.trim()

  // URL (http, https, ftp, file, custom schemes like app stores)
  if (
    /^https?:\/\//i.test(trimmedContent) ||
    /^ftp:\/\//i.test(trimmedContent) ||
    /^file:\/\//i.test(trimmedContent) ||
    /^(market|itms-apps|appstore):\/\//i.test(trimmedContent)
  ) {
    return {
      contentType: "url",
      data: { originalContent: trimmedContent, url: trimmedContent },
    }
  }

  // SMS (sms:number?body=message)
  if (trimmedContent.startsWith("sms:")) {
    const parts = trimmedContent.substring(4).split("?")
    const number = parts[0]
    const body = parts.length > 1 ? new URLSearchParams(parts[1]).get("body") : undefined
    return {
      contentType: "sms",
      data: { originalContent: trimmedContent, number, body },
    }
  }

  // Telephone (tel:number)
  if (trimmedContent.startsWith("tel:")) {
    const number = trimmedContent.substring(4)
    return {
      contentType: "tel",
      data: { originalContent: trimmedContent, number },
    }
  }

  // Email (mailto:email?subject=subject&body=body)
  if (trimmedContent.startsWith("mailto:")) {
    const parts = trimmedContent.substring(7).split("?")
    const email = parts[0]
    let subject: string | undefined
    let body: string | undefined
    if (parts.length > 1) {
      const params = new URLSearchParams(parts[1])
      subject = params.get("subject") || undefined
      body = params.get("body") || undefined
    }
    return {
      contentType: "mailto",
      data: { originalContent: trimmedContent, email, subject, body },
    }
  }

  // Wi-Fi (WIFI:S:<SSID>;T:<AUTH_TYPE>;P:<PASSWORD>;H:<HIDDEN>;;)
  if (trimmedContent.startsWith("WIFI:")) {
    const wifiData: { [key: string]: string } = {}
    trimmedContent
      .substring(5)
      .split(";")
      .forEach((part) => {
        if (part.includes(":")) {
          const [key, value] = part.split(":")
          wifiData[key] = value
        }
      })
    return {
      contentType: "wifi",
      data: {
        originalContent: trimmedContent,
        ssid: wifiData.S,
        authentication: wifiData.T,
        password: wifiData.P,
        hidden: wifiData.H === "true" || wifiData.H === "1",
      },
    }
  }

  // Default to text if no other type matches
  return {
    contentType: "text",
    data: { originalContent: trimmedContent, text: trimmedContent },
  }
}
